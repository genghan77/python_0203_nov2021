# This one will send from the outlook account installed on your computer

import win32com.client

subject = 'email subject'
body = '<html><body>' + 'test' + '</body></html>'
recipient = 'tayml.at.rp@gmail.com'
attachments = ["D:\\abc.txt"]

#Create and send email
olMailItem = 0x0
obj = win32com.client.Dispatch("Outlook.Application")
newMail = obj.CreateItem(olMailItem)
newMail.Subject = subject
newMail.HTMLBody = body
#newMail.Body = body
newMail.To = recipient

for location in attachments:
    newMail.Attachments.Add(Source=location)

newMail.Send()

print("Sent")