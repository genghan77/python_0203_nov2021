#Please replace 6599999999 with your recipient phone number before running this script, around Line 16
#Need to: pip install selenium
#Need to put the Chrome driver (chromedriver.exe) in a folder defined in PATH in environment variable, 
#chromedriver.exe can also be downloaded from https://sites.google.com/chromium.org/driver/

from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
import time

driver = webdriver.Chrome()  # Optional argument, if not specified will search path.

# construct the whatsapp message
# phone number
# message -- need to be urlencoded
message = "hello 123%0aThis is next line"

# replace with your own phone numbers
driver.get("https://api.whatsapp.com/send?phone=6599999999&text="+ message)

# click on whatsapp web button
elem = driver.find_element_by_id("action-button")
elem.send_keys(Keys.RETURN)

# click on the use WhatsApp Link
driver.implicitly_wait(20) # seconds only need to call once, it will wait for 10 sec
elem = driver.find_element_by_link_text("use WhatsApp Web")
actions = ActionChains(driver)
actions.click(elem)
actions.perform()

time.sleep(5)
'''
# the selector can be found using 'right-click->Inspect' in Chrome browser
# In the copy the chrome developer window, right-click->copy->Copy Selector
#elem = driver.find_element_by_css_selector("#main > footer > div._3ee1T._1LkpH.copyable-area > div._3uMse > div > div._3FRCZ.copyable-text.selectable-text")
elem = driver.find_element_by_css_selector("#main > footer > div._2BU3P.tm2tP.copyable-area > div > div > div._2lMWa > div.p3_M1 > div > div._13NKt.copyable-text.selectable-text")
time.sleep(1)
elem.send_keys(Keys.RETURN)
'''

#updated by TML: 31 Oct 2021
inp_xpath = '//*[@id="main"]/footer/div[1]/div/div/div[2]/div[1]/div/div[2]'
input_box = driver.find_element_by_xpath(inp_xpath)
time.sleep(2)
input_box.send_keys(Keys.ENTER)
time.sleep(2)


