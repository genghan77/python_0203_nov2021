# Exchange Rate

import bs4
import requests
import time
import winsound
import datetime

#floatFreq = [261.63, 293.66, 329.63, 349.23, 392, 440, 493.88, 523.25, 587.33]

while True:
    url = "https://www.x-rates.com/table/?from=SGD&amount=1"
    requestObj = requests.get(url)
    requestObj.raise_for_status()
    soup = bs4.BeautifulSoup(requestObj.text, 'html.parser')
    
    #exchange rate
    elements = soup.select("#content > div:nth-child(1) > div > div.col2.pull-right.module.bottomMargin > div.moduleContent > table:nth-child(4) > tbody > tr:nth-child(1) > td:nth-child(3) > a") # $69.90 
    currenttime = datetime.datetime.now()
    print(str(currenttime.strftime("%d-%b-%y %H:%M:%S")) + "\t Price: " + elements[0].text)
    
    if float(elements[0].text) >=1.331451:  # sound this if higher than this price
        winsound.Beep(int(261.63), 300)
        winsound.Beep(int(493.88), 300)
        winsound.Beep(int(493.88), 300)
        
    if float(elements[0].text) <1.331400: # sound this if lower than this price
        winsound.Beep(int(493.88), 300)
        winsound.Beep(int(261.63), 300)
        
    time.sleep(10)
