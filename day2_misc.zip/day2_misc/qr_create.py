# instruction
# need to install the qrcode package
# pip install qrcode

import qrcode
img = qrcode.make('https://bit.ly/py-nov21')
img.save("courseMaterials.png")